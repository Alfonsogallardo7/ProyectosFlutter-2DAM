import 'package:equatable/equatable.dart';

abstract class MeEvent extends Equatable {
  const MeEvent();

  @override
  List<Object> get props => [];
}

class FetchMeWithType extends MeEvent {


  const FetchMeWithType();

  @override
  List<Object> get props => [];
}