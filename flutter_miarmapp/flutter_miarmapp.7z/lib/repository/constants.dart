import 'dart:ui';

import 'package:flutter/cupertino.dart';

class Constant {
  static String apiKey = "d61431a2fb64b6e56c6f086952e63ab6";
  static String public = "public";
  static String nowPlaying = "now_playing";
  static String topRated = "top_rated";
  static String upcoming = "upcoming";
  static String token = "";
  static Image img = '' as Image;

  static const foto_perfil_path = 'avatar_image_path';

}